// Staff mode uses Supabase Auth and the staff-only database policies.
window.ERP_CONFIG = Object.freeze({accessMode:'staff'});
